- Activate the developer mode
- Go to Settings \> Users \> Groups to select a user group
- Edit the group and go to the Access Rights tab
- Uncheck the "Export Access" box on the object of your choice and save

You can also go to Settings \> Technical \> Security \> Access Rights.

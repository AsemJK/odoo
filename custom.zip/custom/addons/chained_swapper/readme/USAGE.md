To use this module, you need to:

1.  Go to the source document in list mode.
2.  Select one or several records.
3.  Click on Action and locate the option "Chained swap: \<name of the
    swap\>".
4.  If one of the selected records doesn't comply with one of the
    constraints, a message will be shown, and the swap won't continue.
5.  If everything is OK, a popup will arise, and you will see a field
    for filling the new value.
6.  Click on "Change", and the swap will be done.
7.  On the chatter of the source document, an entry will be logged for
    reflecting the done swap.

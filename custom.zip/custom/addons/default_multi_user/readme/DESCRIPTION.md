Allows to share user-defined defaults among several users.

To share a default among several users you need to:

1.  Go to *Settings \> Technical \> Actions \> User-defined Defaults*.
2.  Edit a default and fill the field *Available for users* and
    *Available for Groups* with the desired users and/or groups.

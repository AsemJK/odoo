This module allows to use barcodes as launchers of actions.

The action will launch a function that uses the barcode in order to
return an action.

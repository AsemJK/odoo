1.  You must install an application module depending this one (for
    example purchase_substate)

This module includes the ability to define the tier definition domain
and the tier reviewers using python code.
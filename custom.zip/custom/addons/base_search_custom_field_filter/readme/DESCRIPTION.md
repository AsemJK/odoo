This module allows to define custom filters in the search views for an
specific field belonging to the document or any other related document.

This nature makes the definition quite technical, but once done, it adds
the element in the UI for regular user use.

To use this module, you need to:

> - go into the menu of *ir_model*,
> - select the model for which you want to disable the quick create
>   option,
> - enable the option *Avoid quick create*.

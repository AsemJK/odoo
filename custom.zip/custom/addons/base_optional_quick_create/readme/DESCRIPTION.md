This module allows to avoid to *quick create* new records, through
many2one fields, for a specific model. You can configure which models
should allow *quick create*. When specified, the *quick create* option
will always open the standard create form.

Got the idea from <https://twitter.com/nbessi/status/337869826028605441>

This module add option to call "Server Action" when a tier definition is
approved or rejected

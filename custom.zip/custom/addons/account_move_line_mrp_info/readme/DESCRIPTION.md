This module adds the manufacturing orders and unbuild orders to the
account move lines that it generates.

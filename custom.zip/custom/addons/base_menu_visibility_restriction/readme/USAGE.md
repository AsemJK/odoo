To use this module, you need to:

1.  Activate the developer mode
2.  Go to *Settings \> Technical \> User interface \> Menu Items*.
3.  Search for any menu and edit it.
4.  Update "Excluded groups" with one group.
5.  Login with a user of that group, and you won't see such menu.

You can try with demo data for the menu Apps \> App Store and user demo.

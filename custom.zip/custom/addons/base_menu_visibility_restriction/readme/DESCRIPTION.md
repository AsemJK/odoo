This addon lets you assign "excluded groups" to menu items. If a user
belongs to a group that is assigned to a menu item as an excluded group,
the user will not be able to see the menu item.

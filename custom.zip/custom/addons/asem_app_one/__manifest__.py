{
    'name': 'Asem App One',
    'version': '18.0.0.1.0',
    'summary': 'Asem App One',
    'category': 'Productivity',
    'description': 'Asem App One',
    'author': 'Asem',
    'depends': ['base'],
    'data': [
    ],
    'application': True,
}
from odoo import models, fields, api
class AppOneSettings(models.TransientModel):
    _name = 'app.one.settings'